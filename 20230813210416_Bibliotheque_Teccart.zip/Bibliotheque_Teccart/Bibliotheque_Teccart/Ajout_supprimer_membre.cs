﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bibliotheque_Teccart.Class;

namespace Bibliotheque_Teccart
{
   public partial class Ajout_supprimer_membre : Form
   {
      public Ajout_supprimer_membre()
      {
         InitializeComponent();
      }

      private void confirmer_Click(object sender, EventArgs e)
      {
         Membre membre = new Membre();
         membre.Matricule = Int32.Parse(textBox1.Text);
         membre.Nom = textBox2.Text;
         membre.Prenom = textBox3.Text;
         membre.Date_de_naissance = DateTime.Parse(dateTimePicker1.Text);

         if (radioButton1.Checked == true) { membre.Sexe = "Feminin"; }
         if (radioButton2.Checked == true) { membre.Sexe = "Masculin"; }

         bool validation = membre.ajouterLivre(membre);
         if (validation == false)
         {
            Liste_membre.listeMembre.Add(membre);
            MessageBox.Show("Le mebre a été ajouté avec succès");
         }
         else MessageBox.Show("Risque de doublon, le membre existe déja");

         dtgMember.DataSource = null; // effacer les donnes avant dafficher
         dtgMember.DataSource = Liste_membre.listeMembre;
      }

      private void annuler_Click(object sender, EventArgs e)
      {
         this.Close();
      }

      private void supprimer_Click(object sender, EventArgs e)
      {
         if (dtgMember.CurrentRow == null)
         {
            return;
         }
         string matricule = dtgMember.CurrentRow.Cells[0].Value.ToString();

         foreach (Membre membre in Liste_membre.listeMembre)
         {
            if (membre.Matricule == Int32.Parse(matricule))
            {
               Liste_membre.listeMembre.Remove(membre);
               break;
            }

         }
         dtgMember.DataSource = null; // effacer les donnes avant dafficher
         dtgMember.DataSource = Liste_membre.listeMembre;
         MessageBox.Show("Etudiant supprime avec succes");
      }

      private void afficher_membres_Click(object sender, EventArgs e)
      {
         if (Liste_membre.listeMembre.Count() != 0)
         {
            dtgMember.DataSource = null; // effacer les donnes avant dafficher
            dtgMember.DataSource = Liste_membre.listeMembre;
         }
      }
   }
}

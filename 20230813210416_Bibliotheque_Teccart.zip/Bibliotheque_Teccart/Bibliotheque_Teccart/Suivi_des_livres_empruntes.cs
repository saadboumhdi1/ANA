﻿using Bibliotheque_Teccart.Class;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bibliotheque_Teccart
{
   public partial class Suivi_des_livres_empruntes : Form
   {
      public Suivi_des_livres_empruntes()
      {
         InitializeComponent();
      }

      private void Quitter_Click(object sender, EventArgs e)
      {
         this.Close();
      }

      private void afficher_emprunter_Click(object sender, EventArgs e)
      {
         List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
         foreach (var item in Dictionaire_article_emprunter.Dictionaire_article_emprunte)
         {
            list.Insert(0, new KeyValuePair<string, string>(item.Key.Nom, item.Value.Nom_livre));
         }

         dataGridView1.DataSource = null; // effacer les donnes avant dafficher
         dataGridView1.DataSource = list;
         dataGridView1.Columns[0].HeaderText = "Nom du membre";
         dataGridView1.Columns[1].HeaderText = "Nom de l'article emuprunté";
         dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
         dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
      }
   }
}

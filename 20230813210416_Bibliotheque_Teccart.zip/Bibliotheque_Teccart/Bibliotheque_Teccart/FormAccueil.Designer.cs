﻿namespace Bibliotheque_Teccart
{
   partial class FormAccueil
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         Ajout_Supprimer_Livre = new Button();
         Ajout_Personne = new Button();
         Emprunter_livre_magasine = new Button();
         Suivi_livre_emprunter = new Button();
         button1 = new Button();
         SuspendLayout();
         // 
         // Ajout_Supprimer_Livre
         // 
         Ajout_Supprimer_Livre.Location = new Point(109, 20);
         Ajout_Supprimer_Livre.Name = "Ajout_Supprimer_Livre";
         Ajout_Supprimer_Livre.Size = new Size(425, 70);
         Ajout_Supprimer_Livre.TabIndex = 0;
         Ajout_Supprimer_Livre.Text = "Ajouter ou supprimer livre/magasine";
         Ajout_Supprimer_Livre.UseVisualStyleBackColor = true;
         Ajout_Supprimer_Livre.Click += Ajout_supprimer_livre_magasine_Click_1;
         // 
         // Ajout_Personne
         // 
         Ajout_Personne.Location = new Point(109, 111);
         Ajout_Personne.Name = "Ajout_Personne";
         Ajout_Personne.Size = new Size(425, 70);
         Ajout_Personne.TabIndex = 3;
         Ajout_Personne.Text = "Ajouter ou supprimer membre";
         Ajout_Personne.UseVisualStyleBackColor = true;
         Ajout_Personne.Click += Ajout_supprimer_membre_Click;
         // 
         // Emprunter_livre_magasine
         // 
         Emprunter_livre_magasine.Location = new Point(109, 200);
         Emprunter_livre_magasine.Name = "Emprunter_livre_magasine";
         Emprunter_livre_magasine.Size = new Size(425, 70);
         Emprunter_livre_magasine.TabIndex = 4;
         Emprunter_livre_magasine.Text = "Emprunter ou retourner des livres/magasines";
         Emprunter_livre_magasine.UseVisualStyleBackColor = true;
         Emprunter_livre_magasine.Click += Emprunter_livre_magasine_Click;
         // 
         // Suivi_livre_emprunter
         // 
         Suivi_livre_emprunter.Location = new Point(109, 294);
         Suivi_livre_emprunter.Name = "Suivi_livre_emprunter";
         Suivi_livre_emprunter.Size = new Size(425, 70);
         Suivi_livre_emprunter.TabIndex = 6;
         Suivi_livre_emprunter.Text = "Suivi des livres et magasines empruntés";
         Suivi_livre_emprunter.UseVisualStyleBackColor = true;
         Suivi_livre_emprunter.Click += Suivi_livre_emprunter_Click;
         // 
         // button1
         // 
         button1.Location = new Point(109, 385);
         button1.Name = "button1";
         button1.Size = new Size(425, 70);
         button1.TabIndex = 7;
         button1.Text = "Quitter";
         button1.UseVisualStyleBackColor = true;
         button1.Click += button1_Click;
         // 
         // FormAccueil
         // 
         AutoScaleDimensions = new SizeF(8F, 20F);
         AutoScaleMode = AutoScaleMode.Font;
         ClientSize = new Size(643, 477);
         Controls.Add(button1);
         Controls.Add(Suivi_livre_emprunter);
         Controls.Add(Emprunter_livre_magasine);
         Controls.Add(Ajout_Personne);
         Controls.Add(Ajout_Supprimer_Livre);
         Name = "FormAccueil";
         Text = "FormAccueil";
         ResumeLayout(false);
      }

      #endregion

      private Button Ajout_Supprimer_Livre;
      private Button Ajout_Personne;
      private Button Emprunter_livre_magasine;
      private Button Suivi_livre_emprunter;
      private Button button1;
   }
}
﻿namespace Bibliotheque_Teccart
{
   partial class Suivi_des_livres_empruntes
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         dataGridView1 = new DataGridView();
         Quitter = new Button();
         afficher_emprunter = new Button();
         ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
         SuspendLayout();
         // 
         // dataGridView1
         // 
         dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
         dataGridView1.Location = new Point(147, 53);
         dataGridView1.Name = "dataGridView1";
         dataGridView1.RowHeadersWidth = 51;
         dataGridView1.RowTemplate.Height = 29;
         dataGridView1.Size = new Size(527, 280);
         dataGridView1.TabIndex = 0;
         // 
         // Quitter
         // 
         Quitter.Location = new Point(454, 349);
         Quitter.Name = "Quitter";
         Quitter.Size = new Size(230, 66);
         Quitter.TabIndex = 1;
         Quitter.Text = "Retour";
         Quitter.UseVisualStyleBackColor = true;
         Quitter.Click += Quitter_Click;
         // 
         // afficher_emprunter
         // 
         afficher_emprunter.Location = new Point(167, 349);
         afficher_emprunter.Name = "afficher_emprunter";
         afficher_emprunter.Size = new Size(230, 66);
         afficher_emprunter.TabIndex = 2;
         afficher_emprunter.Text = "Afficher liste d'article emprunte";
         afficher_emprunter.UseVisualStyleBackColor = true;
         afficher_emprunter.Click += afficher_emprunter_Click;
         // 
         // Suivi_des_livres_empruntes
         // 
         AutoScaleDimensions = new SizeF(8F, 20F);
         AutoScaleMode = AutoScaleMode.Font;
         ClientSize = new Size(800, 450);
         Controls.Add(afficher_emprunter);
         Controls.Add(Quitter);
         Controls.Add(dataGridView1);
         Name = "Suivi_des_livres_empruntes";
         Text = "Suivi_des_livres_empruntes";
         ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
         ResumeLayout(false);
      }

      #endregion

      private DataGridView dataGridView1;
      private Button Quitter;
      private Button afficher_emprunter;
   }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliotheque_Teccart.Class
{
    internal class Liste_Magasine
    {
        public static List<Magasine> listMagsine = new List<Magasine>();
    }
}

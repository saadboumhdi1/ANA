﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliotheque_Teccart.Class
{
    internal class Membre
    {
        private int matricule;
        private string nom;
        private string prenom;
        private string sexe;
        private DateTime date_de_naissance;

        public int Matricule { get => matricule; set => matricule = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Prenom { get => prenom; set => prenom = value; }
        public string Sexe { get => sexe; set => sexe = value; }
        public DateTime Date_de_naissance { get => date_de_naissance; set => date_de_naissance = value; }

        bool validation = false;
        public bool ajouterLivre(Membre m)
        {
            foreach (Membre membre in Liste_membre.listeMembre)
            {
                if (membre.Matricule == m.Matricule)
                {
                    validation = true;
                }
                else
                {
                    validation = false;
                }

            }
            return validation;
        }
    }
}

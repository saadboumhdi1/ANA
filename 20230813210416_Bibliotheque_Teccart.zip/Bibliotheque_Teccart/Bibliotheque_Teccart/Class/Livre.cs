﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliotheque_Teccart.Class
{
    internal class Livre : Article
    {

        public Livre(int _matricule, string _nom_article, Auteur _auteur,
                          DateTime _date_edition) :
                 base(_matricule, _nom_article, _auteur, _date_edition)
        {
            Type_article = "Livre";
            ++nombre_de_Livre;
        }
        static int nombre_de_Livre = 0;

        bool validation = false;
        public override bool ajouterArticle()
        {
            foreach (Livre livre in Liste_Livre.listLivre)
            {
                if (livre.Matricule == Matricule)
                {
                    validation = true;
                }
                else
                {
                    validation = false;
                }

            }
            return validation;
        }
        public void supprimer_article(string _matricule)
        {
            foreach (Livre livre in Liste_Livre.listLivre)
            {
                if (livre.Matricule == int.Parse(_matricule))
                {
                    Liste_Livre.listLivre.Remove(livre);
                    break;
                }

            }
        }
    }
}

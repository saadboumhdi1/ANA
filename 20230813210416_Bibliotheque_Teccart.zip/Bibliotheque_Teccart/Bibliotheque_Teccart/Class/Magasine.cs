﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliotheque_Teccart.Class
{
    internal class Magasine : Article
    {
        public Magasine(int _matricule, string _nom_article, Auteur _auteur,
                    DateTime _date_edition) :
           base(_matricule, _nom_article, _auteur, _date_edition)
        {
            Type_article = "Magasine";
            ++nombre_de_Magasines;
        }

        static int nombre_de_Magasines = 0;
        bool validation = false;
        public override bool ajouterArticle()
        {
            foreach (Magasine magasine in Liste_Magasine.listMagsine)
            {
                if (magasine.Matricule == Matricule)
                {
                    validation = true;
                }
                else
                {
                    validation = false;
                }
            }
            return validation;
        }
    }
}

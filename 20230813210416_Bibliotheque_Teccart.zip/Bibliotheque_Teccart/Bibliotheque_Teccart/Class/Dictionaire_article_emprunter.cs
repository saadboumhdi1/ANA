﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliotheque_Teccart.Class
{
    internal class Dictionaire_article_emprunter
    {
        public static Dictionary<Membre, Article> Dictionaire_article_emprunte = new Dictionary<Membre, Article>();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliotheque_Teccart.Class
{
    internal class Auteur
    {
        public Auteur(string _nom, string _nationalite)
        {
            nom = _nom;
            nationalite = _nationalite;
        }

        private string nom = "";
        private string nationalite = "";

        public string Nom { get => nom; set => nom = value; }
        public string Nationalite { get => nationalite; set => nationalite = value; }
    }
}

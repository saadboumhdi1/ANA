﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliotheque_Teccart.Class
{
    internal abstract class Article
    {
        protected Article(int _matricule, string _nom_article, Auteur _auteur,
                          DateTime _date_edition)
        {
            matricule = _matricule;
            nom_article = _nom_article;
            auteur = _auteur;
            date_edition = _date_edition;
        }

        private int matricule;
        private string nom_article;
        private Auteur auteur;
        private DateTime date_edition;
        private string type_article;
        private bool est_emprunter = false;

        public int Matricule { get => matricule; set => matricule = value; }
        public string Nom_livre { get => nom_article; set => nom_article = value; }
        public string Type_article { get => type_article; set => type_article = value; }
        public Auteur Auteur { get => auteur; set => auteur = value; }
        public DateTime Date_edition { get => date_edition; set => date_edition = value; }
        public bool Est_emprunter { get => est_emprunter; set => est_emprunter = value; }
        public abstract bool ajouterArticle();

    }
}

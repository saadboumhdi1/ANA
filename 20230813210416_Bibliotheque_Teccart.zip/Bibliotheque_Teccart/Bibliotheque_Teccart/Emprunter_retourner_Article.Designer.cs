﻿namespace Bibliotheque_Teccart
{
   partial class Emprunter_retourner_Article
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         label1 = new Label();
         label2 = new Label();
         label3 = new Label();
         label5 = new Label();
         tbxMatriculeMembre = new TextBox();
         tbxMatriculeArticle = new TextBox();
         emprunter = new Button();
         Anuuler = new Button();
         nom_livre = new Label();
         button1 = new Button();
         SuspendLayout();
         // 
         // label1
         // 
         label1.AutoSize = true;
         label1.Location = new Point(74, 60);
         label1.Name = "label1";
         label1.Size = new Size(0, 20);
         label1.TabIndex = 0;
         // 
         // label2
         // 
         label2.AutoSize = true;
         label2.Location = new Point(74, 91);
         label2.Name = "label2";
         label2.Size = new Size(152, 20);
         label2.TabIndex = 1;
         label2.Text = "Matricule du membre";
         // 
         // label3
         // 
         label3.AutoSize = true;
         label3.Location = new Point(62, 151);
         label3.Name = "label3";
         label3.Size = new Size(0, 20);
         label3.TabIndex = 2;
         // 
         // label5
         // 
         label5.AutoSize = true;
         label5.Location = new Point(74, 320);
         label5.Name = "label5";
         label5.Size = new Size(0, 20);
         label5.TabIndex = 4;
         // 
         // tbxMatriculeMembre
         // 
         tbxMatriculeMembre.Location = new Point(291, 84);
         tbxMatriculeMembre.Name = "tbxMatriculeMembre";
         tbxMatriculeMembre.Size = new Size(226, 27);
         tbxMatriculeMembre.TabIndex = 6;
         // 
         // tbxMatriculeArticle
         // 
         tbxMatriculeArticle.Location = new Point(291, 162);
         tbxMatriculeArticle.Name = "tbxMatriculeArticle";
         tbxMatriculeArticle.Size = new Size(226, 27);
         tbxMatriculeArticle.TabIndex = 7;
         // 
         // emprunter
         // 
         emprunter.Location = new Point(28, 248);
         emprunter.Name = "emprunter";
         emprunter.Size = new Size(143, 53);
         emprunter.TabIndex = 11;
         emprunter.Text = "Emprunter article";
         emprunter.UseVisualStyleBackColor = true;
         emprunter.Click += emprunter_Click;
         // 
         // Anuuler
         // 
         Anuuler.Location = new Point(445, 248);
         Anuuler.Name = "Anuuler";
         Anuuler.Size = new Size(163, 53);
         Anuuler.TabIndex = 12;
         Anuuler.Text = "Retour";
         Anuuler.UseVisualStyleBackColor = true;
         Anuuler.Click += Anuuler_Click;
         // 
         // nom_livre
         // 
         nom_livre.AutoSize = true;
         nom_livre.Location = new Point(74, 169);
         nom_livre.Name = "nom_livre";
         nom_livre.Size = new Size(128, 20);
         nom_livre.TabIndex = 13;
         nom_livre.Text = "Matricule d'article";
         // 
         // button1
         // 
         button1.Location = new Point(235, 248);
         button1.Name = "button1";
         button1.Size = new Size(143, 53);
         button1.TabIndex = 14;
         button1.Text = "Retourner article";
         button1.UseVisualStyleBackColor = true;
         button1.Click += retourner_article_Click;
         // 
         // Emprunter_retourner_Article
         // 
         AutoScaleDimensions = new SizeF(8F, 20F);
         AutoScaleMode = AutoScaleMode.Font;
         ClientSize = new Size(629, 334);
         Controls.Add(button1);
         Controls.Add(nom_livre);
         Controls.Add(Anuuler);
         Controls.Add(emprunter);
         Controls.Add(tbxMatriculeArticle);
         Controls.Add(tbxMatriculeMembre);
         Controls.Add(label5);
         Controls.Add(label3);
         Controls.Add(label2);
         Controls.Add(label1);
         Name = "Emprunter_retourner_Article";
         Text = "suivi_des__livres_empruntes";
         ResumeLayout(false);
         PerformLayout();
      }

      #endregion

      private Label label1;
      private Label label2;
      private Label label3;
      private Label label5;
      private Label label6;
      private TextBox tbxMatriculeMembre;
      private TextBox tbxMatriculeArticle;
      private TextBox textBox4;
      private TextBox textBox5;
      private Button emprunter;
      private Button Anuuler;
      private Label nom_livre;
      private Button button1;
   }
}
﻿namespace Bibliotheque_Teccart
{
   partial class Ajout_supprimer_livre_magasine
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         label1 = new Label();
         nom_livre = new TextBox();
         label2 = new Label();
         auteur = new TextBox();
         label3 = new Label();
         label5 = new Label();
         matricule_livre = new TextBox();
         Ajout_livre_magasine_confirmer = new Button();
         refresh_display = new Button();
         label6 = new Label();
         nationalite_auteur = new TextBox();
         Date_edition = new DateTimePicker();
         label4 = new Label();
         rdbLivre = new RadioButton();
         rdbMagasine = new RadioButton();
         dtgListeArticle = new DataGridView();
         refresh_liste = new Button();
         Supprimer_article = new Button();
         button1 = new Button();
         ((System.ComponentModel.ISupportInitialize)dtgListeArticle).BeginInit();
         SuspendLayout();
         // 
         // label1
         // 
         label1.AutoSize = true;
         label1.Location = new Point(31, 89);
         label1.Name = "label1";
         label1.Size = new Size(42, 20);
         label1.TabIndex = 0;
         label1.Text = "Nom";
         // 
         // nom_livre
         // 
         nom_livre.Location = new Point(208, 82);
         nom_livre.Name = "nom_livre";
         nom_livre.Size = new Size(279, 27);
         nom_livre.TabIndex = 1;
         // 
         // label2
         // 
         label2.AutoSize = true;
         label2.Location = new Point(31, 128);
         label2.Name = "label2";
         label2.Size = new Size(53, 20);
         label2.TabIndex = 3;
         label2.Text = "Auteur";
         // 
         // auteur
         // 
         auteur.Location = new Point(208, 121);
         auteur.Name = "auteur";
         auteur.Size = new Size(279, 27);
         auteur.TabIndex = 4;
         // 
         // label3
         // 
         label3.AutoSize = true;
         label3.Location = new Point(31, 230);
         label3.Name = "label3";
         label3.Size = new Size(104, 20);
         label3.TabIndex = 5;
         label3.Text = "Date d'édition";
         // 
         // label5
         // 
         label5.AutoSize = true;
         label5.Location = new Point(31, 39);
         label5.Name = "label5";
         label5.Size = new Size(71, 20);
         label5.TabIndex = 8;
         label5.Text = "Matricule";
         // 
         // matricule_livre
         // 
         matricule_livre.Location = new Point(208, 36);
         matricule_livre.Name = "matricule_livre";
         matricule_livre.Size = new Size(279, 27);
         matricule_livre.TabIndex = 9;
         // 
         // Ajout_livre_magasine_confirmer
         // 
         Ajout_livre_magasine_confirmer.Location = new Point(50, 346);
         Ajout_livre_magasine_confirmer.Name = "Ajout_livre_magasine_confirmer";
         Ajout_livre_magasine_confirmer.Size = new Size(158, 40);
         Ajout_livre_magasine_confirmer.TabIndex = 10;
         Ajout_livre_magasine_confirmer.Text = "Ajouter";
         Ajout_livre_magasine_confirmer.UseVisualStyleBackColor = true;
         Ajout_livre_magasine_confirmer.Click += Ajout_livre_magasine_confirmer_Click;
         // 
         // refresh_display
         // 
         refresh_display.Location = new Point(869, 346);
         refresh_display.Name = "refresh_display";
         refresh_display.Size = new Size(158, 40);
         refresh_display.TabIndex = 11;
         refresh_display.Text = "Retour";
         refresh_display.UseVisualStyleBackColor = true;
         refresh_display.Click += Ajout_livre_magasine_annuler_Click;
         // 
         // label6
         // 
         label6.AutoSize = true;
         label6.Location = new Point(31, 176);
         label6.Name = "label6";
         label6.Size = new Size(141, 20);
         label6.TabIndex = 12;
         label6.Text = "Nationalité d'auteur";
         // 
         // nationalite_auteur
         // 
         nationalite_auteur.Location = new Point(208, 169);
         nationalite_auteur.Name = "nationalite_auteur";
         nationalite_auteur.Size = new Size(279, 27);
         nationalite_auteur.TabIndex = 13;
         // 
         // Date_edition
         // 
         Date_edition.Location = new Point(208, 223);
         Date_edition.Name = "Date_edition";
         Date_edition.Size = new Size(279, 27);
         Date_edition.TabIndex = 16;
         // 
         // label4
         // 
         label4.AutoSize = true;
         label4.Location = new Point(37, 285);
         label4.Name = "label4";
         label4.Size = new Size(97, 20);
         label4.TabIndex = 17;
         label4.Text = "Type d'article";
         // 
         // rdbLivre
         // 
         rdbLivre.AutoSize = true;
         rdbLivre.Checked = true;
         rdbLivre.Location = new Point(207, 284);
         rdbLivre.Name = "rdbLivre";
         rdbLivre.Size = new Size(61, 24);
         rdbLivre.TabIndex = 18;
         rdbLivre.TabStop = true;
         rdbLivre.Text = "Livre";
         rdbLivre.UseVisualStyleBackColor = true;
         // 
         // rdbMagasine
         // 
         rdbMagasine.AutoSize = true;
         rdbMagasine.Location = new Point(346, 288);
         rdbMagasine.Name = "rdbMagasine";
         rdbMagasine.Size = new Size(94, 24);
         rdbMagasine.TabIndex = 19;
         rdbMagasine.TabStop = true;
         rdbMagasine.Text = "Magasine";
         rdbMagasine.UseVisualStyleBackColor = true;
         // 
         // dtgListeArticle
         // 
         dtgListeArticle.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
         dtgListeArticle.Location = new Point(522, 36);
         dtgListeArticle.Name = "dtgListeArticle";
         dtgListeArticle.RowHeadersWidth = 51;
         dtgListeArticle.RowTemplate.Height = 29;
         dtgListeArticle.Size = new Size(525, 222);
         dtgListeArticle.TabIndex = 20;
         // 
         // refresh_liste
         // 
         refresh_liste.Location = new Point(473, 346);
         refresh_liste.Name = "refresh_liste";
         refresh_liste.Size = new Size(158, 40);
         refresh_liste.TabIndex = 21;
         refresh_liste.Text = "Afficher livres";
         refresh_liste.UseVisualStyleBackColor = true;
         refresh_liste.Click += afficher_livre_click;
         // 
         // Supprimer_article
         // 
         Supprimer_article.Location = new Point(266, 346);
         Supprimer_article.Name = "Supprimer_article";
         Supprimer_article.Size = new Size(158, 40);
         Supprimer_article.TabIndex = 22;
         Supprimer_article.Text = "Supprimer";
         Supprimer_article.UseVisualStyleBackColor = true;
         Supprimer_article.Click += supprimer_Article_Click;
         // 
         // button1
         // 
         button1.Location = new Point(667, 346);
         button1.Name = "button1";
         button1.Size = new Size(158, 40);
         button1.TabIndex = 23;
         button1.Text = "Afficher magasines";
         button1.UseVisualStyleBackColor = true;
         button1.Click += affichier_Magasine_Click;
         // 
         // Ajout_livre_magasine
         // 
         AutoScaleDimensions = new SizeF(8F, 20F);
         AutoScaleMode = AutoScaleMode.Font;
         ClientSize = new Size(1050, 423);
         Controls.Add(button1);
         Controls.Add(Supprimer_article);
         Controls.Add(refresh_liste);
         Controls.Add(dtgListeArticle);
         Controls.Add(rdbMagasine);
         Controls.Add(rdbLivre);
         Controls.Add(label4);
         Controls.Add(Date_edition);
         Controls.Add(nationalite_auteur);
         Controls.Add(label6);
         Controls.Add(refresh_display);
         Controls.Add(Ajout_livre_magasine_confirmer);
         Controls.Add(matricule_livre);
         Controls.Add(label5);
         Controls.Add(label3);
         Controls.Add(auteur);
         Controls.Add(label2);
         Controls.Add(nom_livre);
         Controls.Add(label1);
         Name = "Ajout_livre_magasine";
         Text = "Ajout_livre_magasine";
         ((System.ComponentModel.ISupportInitialize)dtgListeArticle).EndInit();
         ResumeLayout(false);
         PerformLayout();
      }

      #endregion

      private Label label1;
      private TextBox nom_livre;
      private Label label2;
      private TextBox auteur;
      private Label label3;
      private Label label5;
      private TextBox matricule_livre;
      private Button Ajout_livre_magasine_confirmer;
      private Button refresh_display;
      private Label label6;
      private TextBox nationalite_auteur;
      private DateTimePicker Date_edition;
      private Label label4;
      private RadioButton rdbLivre;
      private RadioButton rdbMagasine;
      private DataGridView dtgListeArticle;
      private Button refresh_liste;
      private Button Supprimer_article;
      private Button button1;
   }
}
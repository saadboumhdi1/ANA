﻿namespace Bibliotheque_Teccart
{
   partial class Ajout_supprimer_membre
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         label1 = new Label();
         label2 = new Label();
         label3 = new Label();
         label4 = new Label();
         textBox1 = new TextBox();
         textBox2 = new TextBox();
         textBox3 = new TextBox();
         confirmer = new Button();
         annuler = new Button();
         dateTimePicker1 = new DateTimePicker();
         label5 = new Label();
         radioButton1 = new RadioButton();
         radioButton2 = new RadioButton();
         supprimer = new Button();
         dtgMember = new DataGridView();
         afficher_membres = new Button();
         ((System.ComponentModel.ISupportInitialize)dtgMember).BeginInit();
         SuspendLayout();
         // 
         // label1
         // 
         label1.AutoSize = true;
         label1.Location = new Point(12, 74);
         label1.Name = "label1";
         label1.Size = new Size(39, 20);
         label1.TabIndex = 0;
         label1.Text = "nom";
         // 
         // label2
         // 
         label2.AutoSize = true;
         label2.Location = new Point(12, 114);
         label2.Name = "label2";
         label2.Size = new Size(61, 20);
         label2.TabIndex = 2;
         label2.Text = "prenom";
         // 
         // label3
         // 
         label3.AutoSize = true;
         label3.Location = new Point(12, 220);
         label3.Name = "label3";
         label3.Size = new Size(127, 20);
         label3.TabIndex = 4;
         label3.Text = "date de naissance";
         // 
         // label4
         // 
         label4.AutoSize = true;
         label4.Location = new Point(12, 28);
         label4.Name = "label4";
         label4.Size = new Size(157, 20);
         label4.TabIndex = 6;
         label4.Text = "matricule de personne";
         // 
         // textBox1
         // 
         textBox1.Location = new Point(224, 21);
         textBox1.Name = "textBox1";
         textBox1.Size = new Size(276, 27);
         textBox1.TabIndex = 7;
         // 
         // textBox2
         // 
         textBox2.Location = new Point(224, 67);
         textBox2.Name = "textBox2";
         textBox2.Size = new Size(276, 27);
         textBox2.TabIndex = 8;
         // 
         // textBox3
         // 
         textBox3.Location = new Point(224, 114);
         textBox3.Name = "textBox3";
         textBox3.Size = new Size(276, 27);
         textBox3.TabIndex = 9;
         // 
         // confirmer
         // 
         confirmer.Location = new Point(71, 289);
         confirmer.Name = "confirmer";
         confirmer.Size = new Size(157, 47);
         confirmer.TabIndex = 11;
         confirmer.Text = "Ajouter";
         confirmer.UseVisualStyleBackColor = true;
         confirmer.Click += confirmer_Click;
         // 
         // annuler
         // 
         annuler.Location = new Point(798, 289);
         annuler.Name = "annuler";
         annuler.Size = new Size(167, 47);
         annuler.TabIndex = 12;
         annuler.Text = "Retour";
         annuler.UseVisualStyleBackColor = true;
         annuler.Click += annuler_Click;
         // 
         // dateTimePicker1
         // 
         dateTimePicker1.Location = new Point(222, 218);
         dateTimePicker1.Name = "dateTimePicker1";
         dateTimePicker1.Size = new Size(278, 27);
         dateTimePicker1.TabIndex = 13;
         // 
         // label5
         // 
         label5.AutoSize = true;
         label5.Location = new Point(14, 167);
         label5.Name = "label5";
         label5.Size = new Size(38, 20);
         label5.TabIndex = 14;
         label5.Text = "sexe";
         // 
         // radioButton1
         // 
         radioButton1.AutoSize = true;
         radioButton1.Checked = true;
         radioButton1.Location = new Point(224, 168);
         radioButton1.Name = "radioButton1";
         radioButton1.Size = new Size(80, 24);
         radioButton1.TabIndex = 15;
         radioButton1.TabStop = true;
         radioButton1.Text = "feminin";
         radioButton1.UseVisualStyleBackColor = true;
         // 
         // radioButton2
         // 
         radioButton2.AutoSize = true;
         radioButton2.Location = new Point(351, 168);
         radioButton2.Name = "radioButton2";
         radioButton2.Size = new Size(88, 24);
         radioButton2.TabIndex = 16;
         radioButton2.TabStop = true;
         radioButton2.Text = "masculin";
         radioButton2.UseVisualStyleBackColor = true;
         // 
         // supprimer
         // 
         supprimer.Location = new Point(315, 289);
         supprimer.Name = "supprimer";
         supprimer.Size = new Size(167, 47);
         supprimer.TabIndex = 17;
         supprimer.Text = "Supprimer";
         supprimer.UseVisualStyleBackColor = true;
         supprimer.Click += supprimer_Click;
         // 
         // dtgMember
         // 
         dtgMember.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
         dtgMember.Location = new Point(534, 22);
         dtgMember.Name = "dtgMember";
         dtgMember.RowHeadersWidth = 51;
         dtgMember.RowTemplate.Height = 29;
         dtgMember.Size = new Size(476, 223);
         dtgMember.TabIndex = 18;
         // 
         // afficher_membres
         // 
         afficher_membres.Location = new Point(566, 289);
         afficher_membres.Name = "afficher_membres";
         afficher_membres.Size = new Size(167, 47);
         afficher_membres.TabIndex = 19;
         afficher_membres.Text = "Afficher";
         afficher_membres.UseVisualStyleBackColor = true;
         afficher_membres.Click += afficher_membres_Click;
         // 
         // Ajout_supprimer_membre
         // 
         AutoScaleDimensions = new SizeF(8F, 20F);
         AutoScaleMode = AutoScaleMode.Font;
         ClientSize = new Size(1022, 412);
         Controls.Add(afficher_membres);
         Controls.Add(dtgMember);
         Controls.Add(supprimer);
         Controls.Add(radioButton2);
         Controls.Add(radioButton1);
         Controls.Add(label5);
         Controls.Add(dateTimePicker1);
         Controls.Add(annuler);
         Controls.Add(confirmer);
         Controls.Add(textBox3);
         Controls.Add(textBox2);
         Controls.Add(textBox1);
         Controls.Add(label4);
         Controls.Add(label3);
         Controls.Add(label2);
         Controls.Add(label1);
         Name = "Ajout_supprimer_membre";
         Text = "Ajouter_personne";
         ((System.ComponentModel.ISupportInitialize)dtgMember).EndInit();
         ResumeLayout(false);
         PerformLayout();
      }

      #endregion

      private Label label1;
      private Label label2;
      private Label label3;
      private Label label4;
      private TextBox textBox1;
      private TextBox textBox2;
      private TextBox textBox3;
      private Button confirmer;
      private Button annuler;
      private DateTimePicker dateTimePicker1;
      private Label label5;
      private RadioButton radioButton1;
      private RadioButton radioButton2;
      private Button supprimer;
      private DataGridView dtgMember;
      private Button afficher_membres;
   }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bibliotheque_Teccart.Class;

namespace Bibliotheque_Teccart
{
   public partial class Emprunter_retourner_Article : Form
   {
      public Emprunter_retourner_Article()
      {
         InitializeComponent();
      }

      private void Anuuler_Click(object sender, EventArgs e)
      {
         this.Close();
      }

      private void emprunter_Click(object sender, EventArgs e)
      {
         bool existeLivre = Liste_Livre.listLivre.Any(item =>
            item.Matricule == Int32.Parse(tbxMatriculeArticle.Text)
            && item.Est_emprunter == false);

         bool existeMagasine = Liste_Magasine.listMagsine.Any(item =>
            item.Matricule == Int32.Parse(tbxMatriculeArticle.Text)
            && item.Est_emprunter == false);

         bool existeMembre = Liste_membre.listeMembre.Any(
            item => item.Matricule == Int32.Parse(tbxMatriculeMembre.Text));

         if (existeLivre && existeMembre)
         {
            Livre livre = Liste_Livre.listLivre.Where(item =>
               item.Matricule == Int32.Parse(tbxMatriculeArticle.Text)).FirstOrDefault();

            Liste_Livre.listLivre.Where(item =>
               item.Matricule == Int32.Parse(tbxMatriculeArticle.Text)).FirstOrDefault()
               .Est_emprunter = true;

            Membre membre = Liste_membre.listeMembre.Where(item =>
               item.Matricule == Int32.Parse(tbxMatriculeMembre.Text)).FirstOrDefault();

            Dictionaire_article_emprunter.Dictionaire_article_emprunte[membre] = livre;
            MessageBox.Show("Livre emprunté avec succes");
         }
         else if (existeMagasine && existeMembre)
         {
            Magasine magasine = Liste_Magasine.listMagsine.Where(item =>
               item.Matricule == Int32.Parse(tbxMatriculeArticle.Text)).FirstOrDefault();

            Liste_Magasine.listMagsine.Where(item =>
               item.Matricule == Int32.Parse(tbxMatriculeArticle.Text)).FirstOrDefault()
               .Est_emprunter = true;

            Membre membre = Liste_membre.listeMembre.Where(item =>
               item.Matricule == Int32.Parse(tbxMatriculeMembre.Text)).FirstOrDefault();

            Dictionaire_article_emprunter.Dictionaire_article_emprunte[membre] = magasine;
            MessageBox.Show("Magasine emprunté avec succes");
         }
         else
         {
            MessageBox.Show("Article non emprunté, le membre ou " +
                     "l'article n'existe pas ou deja empurnter");
         }
      }

      private void retourner_article_Click(object sender, EventArgs e)
      {

         Membre membre = Liste_membre.listeMembre.Where(item =>
            item.Matricule == Int32.Parse(tbxMatriculeMembre.Text)).FirstOrDefault();
         Article article = null;
         bool articleEmprunter = Dictionaire_article_emprunter.Dictionaire_article_emprunte.TryGetValue(
            membre, out article);

         if (articleEmprunter && article.Matricule == Int32.Parse(tbxMatriculeArticle.Text))
         {
            Dictionaire_article_emprunter.Dictionaire_article_emprunte.Remove(membre);
            if (article.Type_article == "Magsine")
            {
               Liste_Magasine.listMagsine.Where(item =>
                  item.Matricule == Int32.Parse(tbxMatriculeArticle.Text)).FirstOrDefault()
                  .Est_emprunter = false;
               MessageBox.Show("Magasine retourner avec succes");

            }
            else
            {
               Liste_Livre.listLivre.Where(item =>
               item.Matricule == Int32.Parse(tbxMatriculeArticle.Text)).FirstOrDefault()
               .Est_emprunter = false;
               MessageBox.Show("Livre retourner avec succes");
            }
         }
         else
         {
            MessageBox.Show("Article n'a pas pur etre etourner avec succes");
            return;// do something when the value is not there
         }
      }
   }
}

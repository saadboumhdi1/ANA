﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bibliotheque_Teccart
{
   public partial class FormAccueil : Form
   {
      public FormAccueil()
      {
         InitializeComponent();
      }

      private void Ajout_supprimer_membre_Click(object sender, EventArgs e)
      {
         Ajout_supprimer_membre ajout_personne = new Ajout_supprimer_membre();
         ajout_personne.Show();
      }

      private void Emprunter_livre_magasine_Click(object sender, EventArgs e)
      {
         Emprunter_retourner_Article emprunter_livre_magasine = new Emprunter_retourner_Article();
         emprunter_livre_magasine.Show();

      }

      private void Suivi_livre_emprunter_Click(object sender, EventArgs e)
      {
         Suivi_des_livres_empruntes suivi = new Suivi_des_livres_empruntes();
         suivi.Show();
      }

      private void Ajout_supprimer_livre_magasine_Click_1(object sender, EventArgs e)
      {
         Ajout_supprimer_livre_magasine ajouter_supprimer_livre = new Ajout_supprimer_livre_magasine();
         ajouter_supprimer_livre.Show();
      }

      private void button1_Click(object sender, EventArgs e)
      {
         this.Close();
      }
   }
}

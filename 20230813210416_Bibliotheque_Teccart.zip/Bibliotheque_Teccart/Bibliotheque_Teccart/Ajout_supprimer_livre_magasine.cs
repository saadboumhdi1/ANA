﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bibliotheque_Teccart.Class;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Bibliotheque_Teccart
{
    public partial class Ajout_supprimer_livre_magasine : Form
   {

      public Ajout_supprimer_livre_magasine()
      {
         InitializeComponent();
      }

      private void Ajout_livre_magasine_confirmer_Click(object sender, EventArgs e)
      {

         if (rdbLivre.Checked == true)
         {

            Livre livre = new Livre(Int32.Parse(matricule_livre.Text), nom_livre.Text,
                                    new Auteur(auteur.Text, nationalite_auteur.Text),
                                    DateTime.Parse(Date_edition.Text));

            bool validation = livre.ajouterArticle();
            if (validation == false)
            {
               Liste_Livre.listLivre.Add(livre);
               MessageBox.Show("L'article a ete ajouté avec succes");
            }
            else MessageBox.Show("Risque de doublon, L'article existe deja");
            dtgListeArticle.DataSource = null; // effacer les donnes avant dafficher
            dtgListeArticle.DataSource = Liste_Livre.listLivre;
         }

         if (rdbMagasine.Checked == true)
         {
            Magasine magasine = new Magasine(Int32.Parse(matricule_livre.Text), nom_livre.Text,
                                    new Auteur(auteur.Text, nationalite_auteur.Text),
                                    DateTime.Parse(Date_edition.Text));
            bool validation = magasine.ajouterArticle();
            if (validation == false)
            {
               Liste_Magasine.listMagsine.Add(magasine);
               MessageBox.Show("L'article a été ajouté avec succès");
            }
            else MessageBox.Show("Risque de doublon, l'article existe deja");
            dtgListeArticle.DataSource = null; // effacer les donnes avant dafficher
            dtgListeArticle.DataSource = Liste_Magasine.listMagsine;
         }
      }

      private void Ajout_livre_magasine_annuler_Click(object sender, EventArgs e)
      {
         this.Close();
      }

      private void supprimer_Article_Click(object sender, EventArgs e)
      {
         if (dtgListeArticle.CurrentRow == null)
         {
            return;
         }

         string matricule = dtgListeArticle.CurrentRow.Cells[0].Value.ToString();
         string type_article = dtgListeArticle.CurrentRow.Cells[2].Value.ToString();

         if (type_article == "Livre")
         {
            foreach (Livre livre in Liste_Livre.listLivre)
            {
               if (livre.Matricule == Int32.Parse(matricule))
               {
                  Liste_Livre.listLivre.Remove(livre);
                  break;
               }

            }
            dtgListeArticle.DataSource = null; // effacer les donnes avant dafficher
            dtgListeArticle.DataSource = Liste_Livre.listLivre;
         }
         else
         {
            foreach (Magasine magasine in Liste_Magasine.listMagsine)
            {
               if (magasine.Matricule == Int32.Parse(matricule))
               {
                  Liste_Magasine.listMagsine.Remove(magasine);
                  break;
               }

            }
            dtgListeArticle.DataSource = null; // effacer les donnes avant dafficher
            dtgListeArticle.DataSource = Liste_Magasine.listMagsine;
         }
         MessageBox.Show("Article supprimé avec succes");
      }

      private void afficher_livre_click(object sender, EventArgs e)
      {
         if (Liste_Livre.listLivre.Count() != 0)
         {
            dtgListeArticle.DataSource = null; // effacer les donnes avant dafficher
            dtgListeArticle.DataSource = Liste_Livre.listLivre;
         }
      }

      private void affichier_Magasine_Click(object sender, EventArgs e)
      {
         if (Liste_Magasine.listMagsine.Count() != 0)
         {
            dtgListeArticle.DataSource = null; // effacer les donnes avant dafficher
            dtgListeArticle.DataSource = Liste_Magasine.listMagsine;
         }
      }
   }
}
